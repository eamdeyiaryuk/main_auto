#include <DDSM115.h>

#define motorL 2
#define motorR 1

DDSM115 ddsmL(&Serial2);
DDSM115 ddsmR(&Serial2);

int VL = 0,VLL=0;
int VR = 0,VRR=0;
int head = 0;
void DDSM115init(){
  Serial2.begin(115200);    // RX2,Tx2 rs485
//  keyword Mode Wheel : VELOCITY_LOOP , Mode Joint : POSITION_LOOP
  ddsmR.setMode(motorR, VELOCITY_LOOP);
  ddsmL.setMode(motorL, VELOCITY_LOOP);
}

void DDSM115togo(int V){
  VL = V - head;
  VR = -V - head;
  VLL = constrain(VL,-V,V);
  VRR = constrain(VR,-V,V);
  ddsmR.setVelocity(motorR, VRR, 5);    //ID,Velocity,acceleration (V = -100)
  ddsmL.setVelocity(motorL, VLL, 5);     //ID,Velocity,acceleration (V = 100)
}
